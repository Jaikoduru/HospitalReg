package com.Intern.HospitalReg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalRegApplicationTests {

	@Test
	void contextLoads() {
	}

}
