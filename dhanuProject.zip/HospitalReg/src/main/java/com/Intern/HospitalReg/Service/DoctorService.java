package com.Intern.HospitalReg.Service;

import java.util.List;

import javax.print.Doc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.Intern.HospitalReg.Entity.Doctor;
import com.Intern.HospitalReg.Repo.DoctorRepository;
import com.Intern.HospitalReg.Response.ResponseStructure;

@Service
public class DoctorService {

	@Autowired
	private DoctorRepository doctorRepository;
	
	public ResponseEntity<ResponseStructure<Doctor>> saveDoctor(Doctor doctor) {
		ResponseStructure<Doctor> responseStructure = new ResponseStructure<Doctor>();
		responseStructure.setStatus(HttpStatus.CREATED.value());
		responseStructure.setMessage("successfully inserted");
		responseStructure.setData(doctorRepository.save(doctor));
		return new ResponseEntity<ResponseStructure<Doctor>>(responseStructure,HttpStatus.CREATED);
	}
	
	public List<Doctor> findAll(){
		return doctorRepository.findAll();
	}
	
	public ResponseEntity<ResponseStructure<Doctor>> findDoctorById(int id) {
		
		ResponseStructure<Doctor> responseStructure = new ResponseStructure<Doctor>();
		
		responseStructure.setStatus(HttpStatus.FOUND.value());
		responseStructure.setMessage("successfully fetched");
		responseStructure.setData(doctorRepository.findById(id).get());
		
		return new ResponseEntity<ResponseStructure<Doctor>>(responseStructure,HttpStatus.FOUND);
		
	}
}
