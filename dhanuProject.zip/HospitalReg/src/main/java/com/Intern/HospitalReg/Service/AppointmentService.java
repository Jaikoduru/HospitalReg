package com.Intern.HospitalReg.Service;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Inetrn.HospitalReg.Exceptions.AppointmentNotFoundException;
import com.Intern.HospitalReg.Entity.Appointment;
import com.Intern.HospitalReg.Entity.Doctor;
import com.Intern.HospitalReg.Repo.AppointmentRepo;
import com.Intern.HospitalReg.Repo.DoctorRepository;

@Service
public class AppointmentService {

	@Autowired
	private AppointmentRepo appointmentRepo;
	@Autowired
	private DoctorRepository doctorRepository;
		
	public List<Appointment> fetchAllAppointments() {
	    return appointmentRepo.findAll();
	}
	
	public List<Appointment> getAvailableAppintments(int id){
		Doctor doctor = doctorRepository.findById(id).get();
		if(doctor!=null) {
			LocalDateTime now = LocalDateTime.now();
			return appointmentRepo.findByDoctorAndAvailableIsTrueAndAppointmentTimeAfter(doctor, now);
			
		}
		return Collections.emptyList();
	}
	
	public Appointment bookAppointment(int id,String patientName) {
		Doctor doctor = doctorRepository.findById(id).get();
		if(doctor!=null) {
			List<Appointment> availableAppointments = getAvailableAppintments(id);
			if(!availableAppointments.isEmpty()) {
				//here you need choose an appointment from the available appointments and mark as booked
				Appointment bookAppointment = availableAppointments.get(0);
				bookAppointment.setAvailable(false);
				bookAppointment.setPatientName(patientName);
				return appointmentRepo.save(bookAppointment);
			}
			else {
				throw new AppointmentNotFoundException();
			}
		}
		return null;
	}
	
}
