package com.Intern.HospitalReg.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.Inetrn.HospitalReg.Exceptions.AppointmentNotFoundException;
import com.Intern.HospitalReg.Entity.Appointment;
import com.Intern.HospitalReg.Service.AppointmentService;

@RestController
public class AppointmentController {

	@Autowired
	private  AppointmentService appointmentService;
	
	public ResponseEntity<?> bookAppointment(int id,String patientName) {
		try {
            Appointment bookedAppointment = appointmentService.bookAppointment(id,patientName);
            return ResponseEntity.ok("Appointment booked successfully");
        } catch (AppointmentNotFoundException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
		
	}
	
	@GetMapping("/fetchAllAppoint")
	public List<Appointment> fetchAll(){
		return appointmentService.fetchAllAppointments();
	}	
	
}
