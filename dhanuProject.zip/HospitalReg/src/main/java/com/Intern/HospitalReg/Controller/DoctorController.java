package com.Intern.HospitalReg.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Intern.HospitalReg.Entity.Doctor;
import com.Intern.HospitalReg.Response.ResponseStructure;
import com.Intern.HospitalReg.Service.DoctorService;

import jakarta.websocket.server.PathParam;

@RestController
public class DoctorController {

	@Autowired
	private DoctorService doctorService;
	
	@PostMapping("/save")
	public  ResponseEntity<ResponseStructure<Doctor>> saveDoctor(@RequestBody Doctor doctor) {
		return doctorService.saveDoctor(doctor);
	}
	
	@GetMapping("/fetchDoctor")
	public ResponseEntity<ResponseStructure<Doctor>> fetchDoctor(@RequestParam int id) {
		return doctorService.findDoctorById(id);
	}
	
	@GetMapping("/fetchAllDoctors")
	public List<Doctor> fetchAllDoctors(){
		return doctorService.findAll();
	}
}
