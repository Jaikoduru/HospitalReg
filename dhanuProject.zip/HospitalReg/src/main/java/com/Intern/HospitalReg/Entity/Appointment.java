package com.Intern.HospitalReg.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Appointment {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long appointId;
	private String patientName;
	private LocalDateTime appointmentTime;
	private boolean available;
	
	@ManyToOne
    @JoinColumn(name = "doctor_id")
    private Doctor doctor;

	
	public long getAppointId() {
		return appointId;
	}
	public void setAppointId(long appointId) {
		this.appointId = appointId;
	}
	public String getPatientName() {
		return patientName;
	}
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}
	public LocalDateTime getDateTime() {
		return appointmentTime;
	}
	public void setDateTime(LocalDateTime dateTime) {
		this.appointmentTime = dateTime;
	}
	public boolean isAvailable() {
		return available;
	}
	public void setAvailable(boolean available) {
		this.available = available;
	}

	
}
