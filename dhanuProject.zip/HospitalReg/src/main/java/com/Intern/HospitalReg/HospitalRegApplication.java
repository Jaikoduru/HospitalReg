package com.Intern.HospitalReg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalRegApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalRegApplication.class, args);
	}

}
