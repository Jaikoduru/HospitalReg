package com.Intern.HospitalReg.Repo;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Intern.HospitalReg.Entity.Appointment;
import com.Intern.HospitalReg.Entity.Doctor;

public interface AppointmentRepo extends JpaRepository<Appointment, Integer>
{
	List<Appointment> findByDoctorAndAvailableIsTrueAndAppointmentTimeAfter(Doctor doctor, LocalDateTime appointmentTime);
}
