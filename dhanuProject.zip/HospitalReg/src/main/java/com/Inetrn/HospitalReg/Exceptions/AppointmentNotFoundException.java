package com.Inetrn.HospitalReg.Exceptions;

public class AppointmentNotFoundException extends RuntimeException
{

	private String message = "Appiontment Not Found";

	public AppointmentNotFoundException() {
		
	}
	public String getMessage() {
		return message;
	}
	
}
